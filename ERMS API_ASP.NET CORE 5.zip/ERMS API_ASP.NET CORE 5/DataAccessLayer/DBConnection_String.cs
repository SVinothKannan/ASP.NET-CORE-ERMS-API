using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
namespace DataAccessLayer
{

public class DBConnection_String
	{
		private string ConnString = string.Empty;
		public DBConnection_String(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }
		public string GetConnstring
		{
			get
			{
				return ConnString = ConfigurationExtensions.GetConnectionString(this.Configuration, "DefaultConnection");
			}
		}

	}
}