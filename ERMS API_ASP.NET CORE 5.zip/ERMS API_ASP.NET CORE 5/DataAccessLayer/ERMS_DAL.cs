
using System;
using System.Data;
using Microsoft.ApplicationBlocks.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace DataAccessLayer
{
public class ERMS_DAL
{
    string constring = string.Empty;
      SqlParameter[] oparas = null;
      public ERMS_DAL(DBConnection_String db)
      {
         constring = db.GetConnstring;
      }

      public SqlParameter[] oparameters(Dictionary<dynamic, dynamic> opara = null)
      {
         try
         {
            int count = 0;
            oparas = new SqlParameter[opara.Count];
            foreach (var oparams in opara)
            {
               oparas[count] = new SqlParameter(oparams.Key, oparams.Value);
               count++;
            }
            return oparas;
         }
         catch (Exception exc)
         { throw exc; }
      }

      public dynamic GetSingleData(CommandType objtype, Dictionary<dynamic, dynamic> oparams, string SporQuery)
      {
         try
         {
            dynamic datas = null;
            if (oparams == null)
            {  
               datas = SqlHelper.ExecuteScalar(constring, objtype, SporQuery);
            }
            else
            {
               dynamic oparas = oparameters(oparams);
               datas = SqlHelper.ExecuteDataset(constring, objtype, SporQuery, oparas);
            }
            return datas;
         }
         catch (Exception exc)
         {
            throw exc;
         }

      }
      public dynamic GetData(CommandType objtype, Dictionary<dynamic, dynamic> oparams, string SporQuery)
      {
         try
         {
            dynamic datas = null;
            if (oparams == null)
            {
               datas = SqlHelper.ExecuteDataset(constring, objtype, SporQuery);
            }
            else
            {
               dynamic oparas = oparameters(oparams);
               datas = SqlHelper.ExecuteDataset(constring, objtype, SporQuery, oparas);
            }
            return datas;
         }
         catch (Exception exc)
         {
            throw exc;
         }

      }

      public dynamic PostData(CommandType objtype, Dictionary<dynamic, dynamic> oparams, string SporQuery)
      {
         try
         {
            SqlParameter[] dataparams = oparameters(oparams);
            dataparams[dataparams.Count() - 1].Direction = ParameterDirection.Output;
            dataparams[dataparams.Count() - 2].Direction = ParameterDirection.Output;
            dataparams[dataparams.Count() - 1].Size = 10;
            dataparams[dataparams.Count() - 2].Size = 200;
            dynamic datas = SqlHelper.ExecuteNonQuery(constring, objtype, SporQuery, dataparams);
            string ErrorData = dataparams[dataparams.Count() - 2].Value.ToString();
            string ErrorData1 = dataparams[dataparams.Count() - 1].Value.ToString();
            return ErrorData1;
         }
         catch (Exception exc)
         {
            throw exc;
         }

      } 
}
}