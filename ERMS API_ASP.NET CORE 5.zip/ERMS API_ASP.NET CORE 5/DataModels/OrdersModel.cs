﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class OrdersModel
    {
        public long OrderId { get; set; }
        public long OrderedFoodName { get; set; }
        public DateTime OrderedTime { get; set; }
        public long UserId { get; set; }

        public DateTime OrderDeliveryTime { get; set; }
    }
}
