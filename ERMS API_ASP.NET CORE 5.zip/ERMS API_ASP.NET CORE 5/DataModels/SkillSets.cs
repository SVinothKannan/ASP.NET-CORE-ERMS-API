﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class SkillSets
    {
        public long SkillsId { get; set; } = 0;
        public string SkillName { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public IEnumerable<SkillSets> SkillSetList { get; set; }
    }
}
