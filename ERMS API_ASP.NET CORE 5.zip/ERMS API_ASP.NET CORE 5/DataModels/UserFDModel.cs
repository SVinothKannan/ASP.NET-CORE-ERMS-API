﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class UserFDModel
    {
         public long UsersId { get; set; }

         public string UserName { get; set; }

        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public long FoodId { get; set; }
        public DateTime OrderTime { get; set; }

    }
}
