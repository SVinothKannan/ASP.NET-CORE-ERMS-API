﻿using Newtonsoft.Json;
using System;

namespace DataModels
{
    public static class DB_ErrorModel
    {
        public static string ErrorMessage {get;set;}="ErrorMessage";
        public static string Status {get;set;}="1";
    }

    public class Service_ErrorModel
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }


        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
