﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class UserModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

    public static class UserModel_DBProcParams
    {
        public static string UserName { get; set; } = "UserName";
        public static string Password { get; set; } = "Password";
    }
    public class UserResponse
    {
        public string UserName { get; set; }
        public string EmpName { get; set; }
        public string Role { get; set; }
        public string Token { get; set; }
    }

}
