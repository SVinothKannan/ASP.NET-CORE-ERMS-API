﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{

    public class EmployeeFilterModel
    {
        public long EmpId { get; set; } = 0;
        public string JobTitle { get; set; } = string.Empty;
        public string DepartMent { get; set; } = string.Empty;
        public DateTime StartDate { get; set; } = DateTime.Now;
        public DateTime EndDate { get; set; } = DateTime.Now;
    }

    public static class EmployeeFilterModel_DBProc_Params
    {
        public static string EmpId { get; set; } = "EmpId";
        public static string JobTitle { get; set; } = "JobTitle";
        public static string DepartMent { get; set; } = "DepartMent";
        public static string StartDate { get; set; } = "StartDate";
        public static string EndDate { get; set; } = "EndDate";
    }








    }
