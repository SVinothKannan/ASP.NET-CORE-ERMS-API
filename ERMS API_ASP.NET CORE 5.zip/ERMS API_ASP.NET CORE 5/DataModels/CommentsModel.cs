﻿using System;
using System.Collections.Generic;

namespace DataModels
{
    public class CommentsModel {
        public long CommentsId{get;set;}=0;
        public long EmpId{get;set;}=0;
        public string EmpName { get; set; } = string.Empty;
        public string Author{get;set;}=string.Empty;
        public string Comments{get;set;}=string.Empty;
        public DateTime CreatedDate{get;set;}=DateTime.Now;
        public bool IsActive { get; set; } = true;
        public long SNo { get; set; }
        public long Counts { get; set; }
        public IEnumerable<CommentsModel> CommentsModelList{get;set;}
    }


    public static class Comments_ProcParams
    {
        public static string CommentsId { get; set; } = "CommentsId";
        public static string EmpId { get; set; } = "EmpId";
        public static string Author { get; set; } = "Author";
        public static string Comments { get; set; } = "Comments";
        public static string CreatedDate { get; set; } = "CreatedDate";
        public static string IsActive { get; set; } = "IsActive";
        public static string ErrorMessage { get; set; } = "ErrorMessage";
        public static string Status { get; set; } = "Status";
        public static string MinPage { get; set; } = "MinPage";
        public static string MaxPage { get; set; } = "MaxPage";
    }


}
