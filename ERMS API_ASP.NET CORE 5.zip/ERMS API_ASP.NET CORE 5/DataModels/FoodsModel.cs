﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class FoodsModel
    {
         public long FoodId { get; set; }
         public long FoodName { get; set; }
          
         public DateTime CreatedDate { get; set; } 
    }
}
