using System;
using System.Collections.Generic;

namespace DataModels
{
    public class EmployeeModel
    {
        public long Sno { get; set; }
        public long EmpId { get; set; } = 0;
        public string EmpName { get; set; } = string.Empty;
        public DateTime DOJ { get; set; } = DateTime.Now;
        public string JobTitle { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string DepartMent { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public decimal SalaryMonthly { get; set; } = 0;
        public decimal SalaryAnnually { get; set; } = 0;
        public bool IsLineManager { get; set; } = false;
        public bool IsActive { get; set; } = true;
        public string Images { get; set; } = string.Empty;
        public string Mobile { get; set; } = string.Empty;
        public bool IsWFH { get; set; } = true;
        public string Project { get; set; } = string.Empty;
        public long MstSkill_Id { get; set; } = 0;
        public string SkillSets { get; set; } = string.Empty;
        public bool InBench { get; set; } = false;
        public bool ReHired { get; set; } = false;
        public string SkillSets2 { get; set; } = string.Empty;
        public string HLMgr { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string ExpDetail { get; set; } = string.Empty;
        public string EmpNo { get; set; } = string.Empty;
        public string PortalId { get; set; } = string.Empty;
        public IEnumerable<EmployeeModel> EmployeeModelList { get; set; }
        public long counts { get; set; }
        public long MinPage { get; set; } = 1;
        public long MaxPage { get; set; } = 10;
    }

    public static class EmployeeModel_ProcParams
    {
        public static string EmpId { get; set; } = "EmpId";
        public static string EmpName { get; set; } = "EmpName";
        public static string DOJ { get; set; } = "DOJ";
        public static string JobTitle { get; set; } = "JobTitle";
        public static string Address { get; set; } = "Address";
        public static string DepartMent { get; set; } = "DepartMent";
        public static string SalaryMonthly { get; set; } = "SalaryMonthly";
        public static string SalaryAnnually { get; set; } = "SalaryAnnually";
        public static string IsLineManager { get; set; } = "IsLineManager";
        public static string IsActive { get; set; } = "IsActive";
        public static string ErrorMessage { get; set; } = "ErrorMessage";
        public static string Status { get; set; } = "Status";
    }

    public static class EmployeeProfiles_ProcParams
    {
        public static string EmpType { get; set; } = "EmpType"; 
        public static string EmpLocation { get; set; } = "EmpLocation";
        public static string SkillSetId { get; set; } = "SkillSetId";
        public static string InBench { get; set; } = "InBench";
        public static string IsRemoteWork { get; set; } = "IsRemoteWork";
        public static string MinPage { get; set; } = "MinPage";
        public static string MaxPage { get; set; } = "MaxPage";

    }
}