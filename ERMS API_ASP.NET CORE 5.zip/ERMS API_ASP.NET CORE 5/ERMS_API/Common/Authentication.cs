﻿using DataModels;
using BusinessLayer;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ERMS_API.Common
{
    public class Authentication
    {
        public IConfiguration Configuration { get; }

        public Authentication(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public UserResponse GenerateJSONWebToken(UserResponse userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
                 new Claim(JwtRegisteredClaimNames.Sub, userInfo.UserName),
                 new Claim(JwtRegisteredClaimNames.Email, userInfo.EmpName),
                 new Claim("Role",userInfo.Role),
                 new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(Configuration["Jwt:Issuer"],
              Configuration["Jwt:Issuer"],
              claims,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            userInfo.Token = new JwtSecurityTokenHandler().WriteToken(token);
            return userInfo;
        }

        public UserResponse AuthenticateUser(UserModel login, DataBusinessLayer Businesslayer, Constants constant)
        {
            UserResponse userresponse = null;
            Dictionary<dynamic, dynamic> objdict = new Dictionary<dynamic, dynamic>();
            objdict.Add(DataModels.UserModel_DBProcParams.UserName, login.UserName);
            objdict.Add(DataModels.UserModel_DBProcParams.Password, login.Password);
            DataSet userDset = Businesslayer.GetData(CommandType.StoredProcedure, objdict, constant.SP_User_Authentication);           
            if (userDset != null && userDset.Tables.Count > 0 && userDset.Tables[0].Rows.Count > 0)
            {
                userresponse = new UserResponse();
                userresponse.EmpName = Convert.ToString(userDset.Tables[0].Rows[0]["EmpName"]);
                userresponse.UserName = Convert.ToString(userDset.Tables[0].Rows[0]["UserName"]);
                userresponse.Role = Convert.ToString(userDset.Tables[0].Rows[0]["Role"]);
                var DecyptedPwd = SecurityOperations.DecryptString(Convert.ToString(userDset.Tables[0].Rows[0]["Password"]));
                if (!login.Password.Equals(DecyptedPwd)) { userresponse = null; }
            }
            return userresponse;
        }
    }
}
