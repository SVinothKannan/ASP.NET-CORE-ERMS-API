﻿using System;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace ERMS_API.Common
{
	public class Constants
	{
		public IConfiguration Configuration { get; }

		public Constants(IConfiguration configuration)
		{
			Configuration = configuration;
		}


		#region EmployeeDetails
		public string SP_GetAllEmployees
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:GetAllEmployee"); }
		}
		public string SP_Create_Update_Employees
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:CreateEmployees"); }
		}
		public string SP_Delete_Employees
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:DeleteEmployee"); }
		}
		public string SP_AddComments
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:AddComments"); }
		}
		public string SP_GetComments
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:GetComments"); }
		}

		public string SP_GetEmployees
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:GetEmployees"); }
		}
		public string SP_GetEmployeesFilter
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:GetEmployeesFilter"); }
		}
		public string SP_User_Authentication
        {
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:User_Authentication"); }
		}
		public string SP_GetLocations
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:GetLocations"); }
		}
		public string SP_GetSkillSets
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:GetSkillSets"); }
		}
		public string SP_GetEmployeeProfiles
		{
			get { return Configuration.GetValue<string>("DB_Procs:SP_Employee:GetEmployeeProfiles"); }
		}
		#endregion


	}
}
