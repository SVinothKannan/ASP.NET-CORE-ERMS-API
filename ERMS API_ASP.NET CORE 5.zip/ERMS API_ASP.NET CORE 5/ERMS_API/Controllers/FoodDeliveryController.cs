﻿using BusinessLayer;
using DataAccessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FoodDeliveryController : ControllerBase
    {
        DBConnection_String connection_String;
        DataBusinessLayer BusinessLayer;
        private readonly ILogger<EmployeeController> _logger;
        private readonly IConfiguration _config;
        public FoodDeliveryController(ILogger<EmployeeController> logger, IConfiguration configuration)//,IDistributedcasd cashe)
        {
            _config = configuration;
            _logger = logger;
            //cadad = _csjds;
            connection_String = new DBConnection_String(_config);
            BusinessLayer = new DataBusinessLayer(connection_String);
        }



        [HttpPost("PostOrder/{ObjUsermodles}")]
        public IActionResult GetOrders(DataModels.UserFDModel ObjUsermodles)
        {
            Dictionary<dynamic,dynamic> orders = new Dictionary<dynamic, dynamic>();
            orders.Add("UserName", ObjUsermodles.UserName);
            orders.Add("Address", ObjUsermodles.Address);
            orders.Add("Food", ObjUsermodles.FoodId);
            orders.Add("OrderTime", ObjUsermodles.OrderTime);
            var RegisterOrder = BusinessLayer.PostData(System.Data.CommandType.StoredProcedure, orders, "PostOrder");
            return RegisterOrder;
        }


        [HttpPost("AssignOrdertoCooks/{ObjUsermodles}")]
        public IActionResult GetOrders(DataModels.CooksModel ObjUsermodles)
        {
            Dictionary<dynamic, dynamic> Assignorders = new Dictionary<dynamic, dynamic>();
            Assignorders.Add("cookname", ObjUsermodles.cookName);
            Assignorders.Add("IsAvaila", ObjUsermodles.IsAvialability);
            Assignorders.Add("Food", ObjUsermodles.FoodId);
            var RegisterOrder = BusinessLayer.PostData(System.Data.CommandType.StoredProcedure, Assignorders, "Assignorders");
            return RegisterOrder;
        }

        [HttpGet("FindDeliveryboy")]
        public IActionResult FindDeliveryboy()
        {
            var RegisterOrder = BusinessLayer.GetSingleData(System.Data.CommandType.StoredProcedure, null, "GetDeliveryBoy");
            return RegisterOrder;
        }


        [HttpPost("AssignItemtoDelivery/{DeliveryBoyId},{FoodId},{UserName}")]
        public IActionResult GetOrders(long DeliveryBoyId,long FoodId,string UserName)
        {
            Dictionary<dynamic, dynamic> Assignorders = new Dictionary<dynamic, dynamic>();
            Assignorders.Add("DeliveryBoyId", DeliveryBoyId);
            Assignorders.Add("UserName", UserName);
            Assignorders.Add("Food", FoodId);
            var RegisterOrder = BusinessLayer.PostData(System.Data.CommandType.StoredProcedure, Assignorders, "Assignorders");
            return RegisterOrder;
        }

    }
}
