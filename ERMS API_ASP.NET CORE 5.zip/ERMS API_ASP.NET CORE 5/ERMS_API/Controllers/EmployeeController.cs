﻿using BusinessLayer;
using DataAccessLayer;
using DataModels;
using ERMS_API.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Data;

namespace ERMS_API.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Authorize]
    public class EmployeeController : ControllerBase
    {
        DBConnection_String connection_String;
        DataBusinessLayer BusinessLayer;
        Constants _Constants;
        Authentication _auth;
        private readonly ILogger<EmployeeController> _logger;
        private readonly IConfiguration _config;

        public EmployeeController(ILogger<EmployeeController> logger, IConfiguration configuration)
        {
            _config = configuration;
            _logger = logger;
            connection_String = new DBConnection_String(_config);
            BusinessLayer = new DataBusinessLayer(connection_String);
            _auth = new Authentication(_config);
            _Constants = new Constants(_config);
        }

        [AllowAnonymous]
        [HttpPost("AutheticateUsers/{login}")]
        public IActionResult Login([FromBody] UserModel login)
        {
            IActionResult response = Unauthorized();
            var UserResponse = _auth.AuthenticateUser(login, BusinessLayer, _Constants);

            if (UserResponse != null)
            {
                var tokenString = _auth.GenerateJSONWebToken(UserResponse);
                response = Ok(tokenString);
            }
            return response;
        }

        [HttpGet("GetAllEmployees/{EmpId}")]
        public IActionResult GetAllEmployee(long EmpId = 0)
        {
            Dictionary<dynamic, dynamic> objdict = new Dictionary<dynamic, dynamic>();
            objdict.Add(DataModels.EmployeeModel_ProcParams.EmpId, EmpId);
            DataSet data = BusinessLayer.GetData(CommandType.StoredProcedure, objdict, _Constants.SP_GetAllEmployees);
            EmployeeModel employeeModel = new EmployeeModel();
            employeeModel.EmployeeModelList = CommonConversions.GetJSONModel<EmployeeModel>(data);
            return Ok(employeeModel.EmployeeModelList);
        }

        [HttpPost("AddEmployees/{ObjemployeeModel}")]
        public IActionResult AddEmployee([FromBody] EmployeeModel ObjemployeeModel)
        {
            #region ModelValues_Dictionary
            Dictionary<dynamic, dynamic> Ipvalues = new Dictionary<dynamic, dynamic>();
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.EmpId, ObjemployeeModel.EmpId);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.EmpName, ObjemployeeModel.EmpName);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.DOJ, ObjemployeeModel.DOJ);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.JobTitle, ObjemployeeModel.JobTitle);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.Address, ObjemployeeModel.Address);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.DepartMent, ObjemployeeModel.DepartMent);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.SalaryMonthly, ObjemployeeModel.SalaryMonthly);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.SalaryAnnually, ObjemployeeModel.SalaryAnnually);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.IsLineManager, ObjemployeeModel.IsLineManager);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.ErrorMessage, DB_ErrorModel.ErrorMessage);
            Ipvalues.Add(DataModels.EmployeeModel_ProcParams.Status, DB_ErrorModel.Status);
            #endregion
            dynamic PostData_result = BusinessLayer.PostData(CommandType.StoredProcedure, Ipvalues, _Constants.SP_Create_Update_Employees);
            var rest = new { result = "" };
            switch (PostData_result)
            {
                case "1":
                    rest = new { result = "Employee created Successfully" };
                    break;
                case "2":
                    rest = new { result = "Employee details updated Successfully" };
                    break;
                case "-2":
                    rest = new { result = "Employee Exists!" };
                    break;
                default:
                    rest = new { result = "Error! Please try again!" };
                    break;
            }
            return Ok(rest);
        }

        [HttpDelete("DeleteEmployee/{EmpId}")]
        public IActionResult DeleteEmployee(long EmpId = 0)
        {
            Dictionary<dynamic, dynamic> objdict = new Dictionary<dynamic, dynamic>();
            objdict.Add(DataModels.EmployeeModel_ProcParams.EmpId, EmpId);
            objdict.Add(DataModels.EmployeeModel_ProcParams.ErrorMessage, DB_ErrorModel.ErrorMessage);
            objdict.Add(DataModels.EmployeeModel_ProcParams.Status, DB_ErrorModel.Status);
            dynamic data = BusinessLayer.PostData(CommandType.StoredProcedure, objdict, _Constants.SP_Delete_Employees);
            var rest = new { result = "" };
            switch (data)
            {
                case "1":
                    rest = new { result = "Employee Details Deleted Successfully" };
                    break;
                default:
                    rest = new { result = "Error! Please try again!" };
                    break;
            }
            return Ok(rest);
        }

        [HttpPost("AddComments/{Objcommentsmodel}")]
        public IActionResult AddComments([FromBody] CommentsModel Objcommentsmodel)
        {
            Dictionary<dynamic, dynamic> objdict = new Dictionary<dynamic, dynamic>();
            objdict.Add(DataModels.Comments_ProcParams.EmpId, Objcommentsmodel.EmpId);
            objdict.Add(DataModels.Comments_ProcParams.CommentsId, Objcommentsmodel.CommentsId);
            objdict.Add(DataModels.Comments_ProcParams.Author, Objcommentsmodel.Author);
            objdict.Add(DataModels.Comments_ProcParams.Comments, Objcommentsmodel.Comments);
            objdict.Add(DataModels.Comments_ProcParams.ErrorMessage, DB_ErrorModel.ErrorMessage);
            objdict.Add(DataModels.Comments_ProcParams.Status, DB_ErrorModel.Status);
            dynamic data = BusinessLayer.PostData(CommandType.StoredProcedure, objdict, _Constants.SP_AddComments);
            var rest = new { result = "" };
            switch (data)
            {
                case "1":
                    rest = new { result = "Comments Added Successfully" };
                    break;
                case "2":
                    rest = new { result = "Comments details updated Successfully" };
                    break;
                default:
                    rest = new { result = "Error! Please try again!" };
                    break;
            }
            return Ok(rest);
        }

        [HttpGet("GetAllEComments/{CommentsId},{MinPage},{MaxPage},{IsTotalCount}")]
        public IActionResult GetAllComments(long CommentsId = 0, long MinPage = 1, long MaxPage = 10, bool IsTotalCount = false)
        {
            Dictionary<dynamic, dynamic> objdict = new Dictionary<dynamic, dynamic>();
            objdict.Add(DataModels.Comments_ProcParams.CommentsId, CommentsId);
            objdict.Add(DataModels.Comments_ProcParams.MinPage, MinPage);
            objdict.Add(DataModels.Comments_ProcParams.MaxPage, MaxPage);
            DataSet data = BusinessLayer.GetData(CommandType.StoredProcedure, objdict, _Constants.SP_GetComments);
            CommentsModel employeeModel = new CommentsModel();
            employeeModel.CommentsModelList = CommonConversions.GetJSONModel<CommentsModel>(data);
            return Ok(employeeModel.CommentsModelList);
        }

        [HttpGet("GetEmployees/{IsLineManager}")]
        public IActionResult GetEmployees(bool IsLineManager = false)
        {
            Dictionary<dynamic, dynamic> objdict = new Dictionary<dynamic, dynamic>();
            objdict.Add(DataModels.EmployeeModel_ProcParams.IsLineManager, IsLineManager);
            DataSet data = BusinessLayer.GetData(CommandType.StoredProcedure, objdict, _Constants.SP_GetEmployees);
            EmployeeModel employeeModel = new EmployeeModel();
            employeeModel.EmployeeModelList = CommonConversions.GetJSONModel<EmployeeModel>(data);
            return Ok(employeeModel.EmployeeModelList);
        }

        [HttpPost("GetEmployeesFilter/{objemployeeFilterModel}")]
        public IActionResult GetEmployeesFilter([FromBody] EmployeeFilterModel objemployeeFilterModel)
        {
            Dictionary<dynamic, dynamic> objdict = new Dictionary<dynamic, dynamic>();
            objdict.Add(DataModels.EmployeeFilterModel_DBProc_Params.EmpId, objemployeeFilterModel.EmpId);
            objdict.Add(DataModels.EmployeeFilterModel_DBProc_Params.JobTitle, objemployeeFilterModel.JobTitle);
            objdict.Add(DataModels.EmployeeFilterModel_DBProc_Params.DepartMent, objemployeeFilterModel.DepartMent);
            objdict.Add(DataModels.EmployeeFilterModel_DBProc_Params.StartDate, objemployeeFilterModel.StartDate);
            objdict.Add(DataModels.EmployeeFilterModel_DBProc_Params.EndDate, objemployeeFilterModel.EndDate);
            DataSet data = BusinessLayer.GetData(CommandType.StoredProcedure, objdict, _Constants.SP_GetEmployeesFilter);
            EmployeeModel employeeModel = new EmployeeModel();
            employeeModel.EmployeeModelList = CommonConversions.GetJSONModel<EmployeeModel>(data);
            return Ok(employeeModel.EmployeeModelList);
        }

        [HttpGet("GetLocations")]
        public IActionResult GetLocations()
        {
            DataSet data = BusinessLayer.GetData(CommandType.StoredProcedure, null, _Constants.SP_GetLocations);
            Locations LocationModel = new Locations();
            LocationModel.LocationList = CommonConversions.GetJSONModel<Locations>(data);
            return Ok(LocationModel.LocationList);
        }

        [HttpGet("GetSkillSets")]
        public IActionResult GetSkillSets()
        {
            DataSet data = BusinessLayer.GetData(CommandType.StoredProcedure, null, _Constants.SP_GetSkillSets);
            SkillSets LocationModel = new SkillSets();
            LocationModel.SkillSetList = CommonConversions.GetJSONModel<SkillSets>(data);
            return Ok(LocationModel.SkillSetList);
        }

        [HttpPost("GetEmployeeProfiles/{employeeModel}")]
        public IActionResult GetEmployeeProfiles([FromBody] EmployeeModel employeeModel)
        {
            Dictionary<dynamic, dynamic> objdict = new Dictionary<dynamic, dynamic>();
            objdict.Add(EmployeeProfiles_ProcParams.EmpType,employeeModel.IsLineManager);
            objdict.Add(EmployeeProfiles_ProcParams.EmpLocation, employeeModel.Location);
            objdict.Add(EmployeeProfiles_ProcParams.SkillSetId, employeeModel.MstSkill_Id);
            objdict.Add(EmployeeProfiles_ProcParams.InBench, employeeModel.InBench);
            objdict.Add(EmployeeProfiles_ProcParams.IsRemoteWork, employeeModel.IsWFH);
            objdict.Add(EmployeeProfiles_ProcParams.MinPage, employeeModel.MinPage);
            objdict.Add(EmployeeProfiles_ProcParams.MaxPage, employeeModel.MaxPage);
            DataSet data = BusinessLayer.GetData(CommandType.StoredProcedure, objdict, _Constants.SP_GetEmployeeProfiles);
            EmployeeModel empModel = new EmployeeModel();
            empModel.EmployeeModelList = CommonConversions.GetJSONModel<EmployeeModel>(data);
            return Ok(empModel.EmployeeModelList);
        }

    }

}

