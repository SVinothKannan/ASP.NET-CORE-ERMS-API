﻿using Abstract_Factory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Factory
{
    public interface IMobile
    {
        List<string> GetMobileDetails();
    }

    public abstract class MobileProduct : IMobile
    {
        public abstract List<string> GetMobileDetails();
    }

    public  class SamsungNormalMobile: MobileProduct
    {
        public override List<string> GetMobileDetails()
        {
            return new List<string> { "Normal Mobile - Samsung 1011", "Normal Mobile - Samsung 111" };
        }
    }

    public class SamsungSmartMobile : MobileProduct
    {
        public override List<string> GetMobileDetails()
        {
            return new List<string> { "Smart Mobile - Samsung Galaxy 101" };
        }
    }


    public abstract class MobileFactory
    {
        public abstract MobileProduct GetMobiles(string MobileName);

        public static dynamic CreateMobileFactory(string MobileType)
        {
            if (MobileType == "NormalPhone")
                return new NormalMobileFactory();
            else
                return new SmartMobileFactory();
        }
    }


    public class NormalMobileFactory : MobileFactory
    {
        public override MobileProduct GetMobiles(string MobileName)
        {
            if (MobileName == "Samsung Normal Mobile")
                return new SamsungNormalMobile();
            else
                return null;
        }
    }


    public class SmartMobileFactory : MobileFactory
    {
        public override MobileProduct GetMobiles(string MobileName)
        {
            if (MobileName == "Samsung Smart Mobile")
                return new SamsungSmartMobile();
            else
                return null;
        }
    }

    public class data
    {
        MobileFactory fac = null;
        MobileProduct products = null;
        List<string> mobdets = null;

        public void methods()
        {
            fac = MobileFactory.CreateMobileFactory("NormalPhone");
            string mobilename=fac.GetType().Name;

            products = fac.GetMobiles("Samasung Normal Mobile");
            mobdets = products.GetMobileDetails();
            foreach (var item in mobdets)
            {
                Console.WriteLine("Course code: " + item);
            }
        }
    }


}
