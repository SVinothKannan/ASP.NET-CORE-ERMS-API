﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Factory
{
    public interface Isubject
    {
        void Registerobserver();
        void Removeobserver();
        string Notifyobserver();
    }

    public interface Iobserver
    {
        string UpdateAvailablity();
    }

    public class observer:Iobserver
    {
        string _FoodName = "";
        string _Availablity = "";
        public observer(string FoodName, string Availablity)
        {
            FoodName = _FoodName;
            Availablity = _Availablity;
        }

        public string UpdateAvailablity() {
            return _Availablity;
        }

    }


    public class Subject : Isubject
    {
        List<string> observers = new List<string>();
        string Food = ""; string Username = "";
        string Available = "";
        public Subject(string _Food,string _Available)
        {
            Food = _Food;
            Available = _Available;
        }

        public string Notifyobserver()
        {
            if(Available== "Available"&& Food!="")
            {
                return "Food is Available";
            }
            return "Not Available";
        }


        public void Registerobserver()
        {
            observers.Add(Username);
        }

        public void Removeobserver()
        {
            observers.Remove(Username);
        }

    }

}
