﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using DataAccessLayer;

namespace BusinessLayer
{
    public class DataBusinessLayer
    {
        ERMS_DAL objDAL;
		public DataBusinessLayer(DBConnection_String connection_String)
		{
			objDAL = new ERMS_DAL(connection_String);
		}

		public dynamic GetSingleData(CommandType objtype, Dictionary<dynamic, dynamic> oparams, string SporQuery)
		{
			try
			{
				return objDAL.GetSingleData(objtype,oparams,SporQuery);
			}
			catch (Exception exc) { throw exc; }
		}

		public dynamic GetData(CommandType objtype, Dictionary<dynamic, dynamic> oparams, string SporQuery)
		{
			try
			{
				return objDAL.GetData(objtype, oparams, SporQuery);
			}
			catch (Exception exc) { throw exc; }
		}

		public dynamic PostData(CommandType objtype, Dictionary<dynamic, dynamic> oparams, string SporQuery)
		{
			try
			{
				return objDAL.PostData(objtype, oparams, SporQuery);
			}
			catch (Exception exc) { throw exc; }
		}
    }
}
